import re
from google.cloud import datastore
from flask import Flask, request, jsonify, _request_ctx_stack, make_response
import requests
import constants
from functools import wraps
import json

from six.moves.urllib.request import urlopen
from flask_cors import cross_origin
from jose import jwt


import json
from os import environ as env, error
from werkzeug.exceptions import HTTPException

from dotenv import load_dotenv, find_dotenv
from flask import Flask
from flask import jsonify
from flask import redirect
from flask import render_template
from flask import session
from flask import url_for
from authlib.integrations.flask_client import OAuth
from six.moves.urllib.parse import urlencode


app = Flask(__name__)
app.secret_key = 'SECRET_KEY'

client = datastore.Client()

CLIENT_ID = 'rVeNBIJLoXNkrnNpeKfM1iCn7n1YzwCb'
CLIENT_SECRET = 'SKvb-PSXZNge8eTxibId4iUex9jMoDWZ43ySGPGTl06eBYXUuuRbs1JEh_HeVTwt'
DOMAIN = 'final-project-linxinw.us.auth0.com'
#CALLBACK_URL = 'http://localhost:8080/callback'
CALLBACK_URL = 'https://final-project-314709.uc.r.appspot.com/callback'

ALGORITHMS = ["RS256"]


oauth = OAuth(app)

auth0 = oauth.register(
    'auth0',
    client_id=CLIENT_ID,
    client_secret=CLIENT_SECRET,
    api_base_url="https://" + DOMAIN,
    access_token_url="https://" + DOMAIN + "/oauth/token",
    authorize_url="https://" + DOMAIN + "/authorize",
    client_kwargs={
        'scope': 'openid profile email',
    },
)


# This code is adapted from https://auth0.com/docs/quickstart/backend/python/01-authorization?_ga=2.46956069.349333901.1589042886-466012638.1589042885#create-the-jwt-validation-decorator

class AuthError(Exception):
    def __init__(self, error, status_code):
        self.error = error
        self.status_code = status_code


@app.errorhandler(AuthError)
def handle_auth_error(ex):
    response = jsonify(ex.error)
    response.status_code = ex.status_code
    return response
    
def verify_jwt(request):
    auth_header = request.headers['Authorization'].split()
    token = auth_header[1]
    
    jsonurl = urlopen("https://"+ DOMAIN+"/.well-known/jwks.json")
    jwks = json.loads(jsonurl.read())
    try:
        unverified_header = jwt.get_unverified_header(token)
    except jwt.JWTError:
        raise AuthError({"code": "invalid_header",
                        "description":
                            "Invalid header. "
                            "Use an RS256 signed JWT Access Token"}, 401)
    if unverified_header["alg"] == "HS256":
        raise AuthError({"code": "invalid_header",
                        "description":
                            "Invalid header. "
                            "Use an RS256 signed JWT Access Token"}, 401)
    rsa_key = {}
    for key in jwks["keys"]:
        if key["kid"] == unverified_header["kid"]:
            rsa_key = {
                "kty": key["kty"],
                "kid": key["kid"],
                "use": key["use"],
                "n": key["n"],
                "e": key["e"]
            }
    if rsa_key:
        try:
            payload = jwt.decode(
                token,
                rsa_key,
                algorithms=ALGORITHMS,
                audience=CLIENT_ID,
                issuer="https://"+ DOMAIN+"/"
            )
        except jwt.ExpiredSignatureError:
            raise AuthError({"code": "token_expired",
                            "description": "token is expired"}, 401)
        except jwt.JWTClaimsError:
            raise AuthError({"code": "invalid_claims",
                            "description":
                                "incorrect claims,"
                                " please check the audience and issuer"}, 401)
        except Exception:
            raise AuthError({"code": "invalid_header",
                            "description":
                                "Unable to parse authentication"
                                " token."}, 401)

        return payload
    else:
        raise AuthError({"code": "no_rsa_key",
                            "description":
                                "No RSA key in JWKS"}, 401)


@app.route('/')
def login():
    return auth0.authorize_redirect(redirect_uri=CALLBACK_URL)

@app.route('/login')
def login2():
    return auth0.authorize_redirect(redirect_uri=CALLBACK_URL)

@app.route('/ui_login')
def login3():
    return auth0.authorize_redirect(redirect_uri=CALLBACK_URL)

@app.route('/users', methods=['GET'])
def users():
    if request.method == 'GET':
        res = check_accept_mimetypes(request)
        if res != None:
            return res
        # at least display users' unique ID
        # returns all user
        query = client.query(kind=constants.users)
        results = list(query.fetch())
        for e in results:
            e['id'] = e.key.id
        res = make_response(json.dumps(results))
        res.mimetype = 'application/json'
        res.status_code = 200
        return res
    else:
        res = make_response(json.dumps('Method not recogonized'))
        res.mimetype = 'application/json'
        res.status_code = 405
        return res


@app.route('/loads', methods=['GET', 'POST'])
def loads():
    if request.method == 'GET':
        res = check_accept_mimetypes(request)
        if res != None:
            return res
        # display all loads since this entity is not related to the user
        query = client.query(kind=constants.loads)
        results = list(query.fetch())
        num = len(results)
        response = {
            'num_loads' : num,
            'loads': results
        }
        res = make_response(json.dumps(response))
        res.mimetype = 'application/json'
        res.status_code = 200

        q_limit = int(request.args.get('limit', '5'))
        q_offset = int(request.args.get('offset', '0'))
        l_iterator = query.fetch(limit= q_limit, offset=q_offset)
        pages = l_iterator.pages
        results = list(next(pages))
        num = len(results)
        if l_iterator.next_page_token:
            next_offset = q_offset + q_limit
            next_url = request.base_url + "?limit=" + str(q_limit) + "&offset=" + str(next_offset)
        else:
            next_url = None
        for e in results:
            e["id"] = e.key.id
            e['self'] = request.url + '/' +  str(e.key.id)
        output = {
            "num_loads": num,
            "loads": results
        }
        if next_url:
            output["next"] = next_url
        res = make_response(json.dumps(output))
        res.mimetype = 'application/json'
        res.status_code = 200
        return res
    elif request.method == 'POST':
        # create a load
        content = request.get_json()
        new_load = datastore.entity.Entity(key=client.key(constants.loads))
        new_load['carrier'] = None
        new_load['weight'] = content['weight']
        new_load['creation_date'] = content['creation_date']
        new_load['length'] = content['length']
        client.put(new_load)
        new_load['self'] = request.host_url + 'loads/' + str(new_load.key.id)
        new_load['id'] = new_load.key.id
        res = make_response(json.dumps(new_load))
        res.mimetype = 'application/json'
        res.status_code = 201
        return res
    else:
        res = make_response(json.dumps('Method not recogonized'))
        res.mimetype = 'application/json'
        res.status_code = 405
        return res


@app.route('/boats', methods=['GET', 'POST'])
def boats():
    if 'Authorization' not in request.headers:
        # auth is missing
        return (jsonify(''),401)
    payload = verify_jwt(request)
    
    if 'application/json' not in request.accept_mimetypes:
        res = make_response(json.dumps(''))
        res.mimetype = 'application/json'
        res.status_code = 406
        return res

    current_user = None

    #display only user's boats
    query = client.query(kind=constants.boats)
    query2 = client.query(kind=constants.users)
    all_users = list(query2.fetch())
    
    for user in all_users:
        if user['user_id'] == payload['sub']:
            current_user = user
            break
    if request.method == 'GET':
        res = check_accept_mimetypes(request)
        if res != None:
            return res
        q_limit = int(request.args.get('limit', '5'))
        q_offset = int(request.args.get('offset', '0'))
        l_iterator = query.fetch(limit= q_limit, offset=q_offset)
        pages = l_iterator.pages
        results = list(next(pages))
        boat_list = []
        for boat in results:
            if 'owner' in boat and boat['owner'] == current_user.key.id:
                boat_list.append(boat)
        num = len(results)
        if l_iterator.next_page_token:
            next_offset = q_offset + q_limit
            next_url = request.base_url + "?limit=" + str(q_limit) + "&offset=" + str(next_offset)
        else:
            next_url = None
        for e in results:
            e["id"] = e.key.id
            e['self'] = request.url + '/' +  str(e.key.id)
        output = {
            "num_boats": num,
            "boats": boat_list
        }
        if next_url:
            output["next"] = next_url
        res = make_response(json.dumps(output))
        res.mimetype = 'application/json'
        res.status_code = 200
        return res
    elif request.method == 'POST':
        content = request.get_json()
        if not is_boat_unique(content['name']):
            error_message = {
                "Error": "The name of the boat is duplicated"
            }
            res = make_response(json.dumps(error_message))
            res.mimetype = 'application/json'
            res.status_code = 403
            return res
        new_boat = datastore.entity.Entity(key=client.key(constants.boats))
        new_boat['owner'] = current_user.key.id
        new_boat['type'] = content['type']
        new_boat['creation_date'] = content['creation_date']
        new_boat['name'] = content['name']
        new_boat['loads'] = None
        client.put(new_boat)
        new_boat['self'] = request.host_url + 'boats/' + str(new_boat.key.id)
        new_boat['id'] = new_boat.key.id
        res = make_response(json.dumps(new_boat))
        res.mimetype = 'application/json'
        res.status_code = 201
        return res
    else:
        res = make_response(json.dumps('Method not recogonized'))
        res.mimetype = 'application/json'
        res.status_code = 405
        return res


@app.route('/boats/<boat_id>', methods=['GET', 'DELETE', 'PATCH', 'PUT'])
def boat(boat_id):
    if 'Authorization' not in request.headers:
        # auth is missing
        return (jsonify(''),401)
    payload = verify_jwt(request) # check if jwt is valid

    boat_key = client.key(constants.boats, int(boat_id))
    boat = client.get(key=boat_key)
    
    if boat == None:
        error_message = {
            "Error": "The specified boat does not exist" 
        }
        return (error_message, 404)

    user_key = client.key(constants.users, int(boat['owner']))
    user = client.get(key=user_key)

    
    if user['user_id'] != payload['sub']:
        res = make_response(json.dumps('Reject request'))
        res.mimetype = 'application/json'
        res.status_code = 403
        return res

    if request.method == 'GET':
        res = check_accept_mimetypes(request)
        if res != None:
            return res
        boat['id'] = boat.key.id
        load_list = []
        if boat['loads'] != None:
            for load in boat['loads']:
                load_key = client.key(constants.loads, int(load))
                load = client.get(key=load_key)
                load['id'] = load.key.id
                load['self'] = request.host_url + 'loads/' + str(load.key.id)
                load.pop('carrier', None)
                load_list.append(load)
        boat['loads'] = load_list
        res = make_response(json.dumps(boat))
        res.mimetype = 'application/json'
        res.status_code = 200
        return res

    elif request.method == 'PATCH' or request.method == 'PUT':
        content = request.get_json()
        if content == None or ("name" not in content and "type" not in content and "creation_date" not in content):
            error_message = {
                "Error": "The request object is missing all of the required attributes"
            }
            return (error_message, 400)
        boat_key = client.key(constants.boats, int(boat_id))
        boat = client.get(key=boat_key)

        if boat == None:
            error_message = {
                "Error": "No boat with this boat_id exists"
            }
            return (error_message, 404)
        
        if 'name' in content:
            boat['name'] = content['name']
        if 'type' in content:
            boat['type'] = content['type']
        if 'creation_date' in content:
            boat['creation_date'] = content['creation_date']

        client.put(boat)
        boat['id'] = boat.key.id
        boat['self'] = request.url
        res = make_response(json.dumps(boat))
        res.mimetype = 'application/json'
        res.status_code = 202
        return res
    elif request.method == 'DELETE':
        # to delete a boat, delete all loads which are assigned to this boat
        query = client.query(kind=constants.loads)
        all_loads = list(query.fetch())
        for load in all_loads:
            if load['carrier'] == boat.key.id:
                load['carrier'] = None
                client.put(load)
        client.delete(boat_key)
        res = make_response(json.dumps(''))
        res.mimetype = 'application/json'
        res.status_code = 204
        return res
    else:
        return jsonify(error='Method not recogonized')


@app.route('/loads/<id>', methods=['GET', 'PATCH', 'PUT', 'DELETE'])
def load(id):
    load_key = client.key(constants.loads, int(id))
    load = client.get(key=load_key)

    if request.method == 'GET':
        res = check_accept_mimetypes(request)
        if res != None:
            return res

        if load == None:
            error_message = {
                "Error": "No load with this load_id exists"
            }
            res = make_response(json.dumps(error_message))
            res.mimetype = 'application/json'
            res.status_code = 404
            return res

        load['id'] = load.key.id
        if load['carrier'] != None:
            carrier_key = client.key(constants.boats, int(load['carrier']))
            carrier = client.get(key=carrier_key)
            carrier['id'] = carrier.key.id
            carrier['self'] = request.host_url + 'boats/' + str(carrier.key.id)
            carrier.pop('loads', None)
            load['carrier'] = carrier
            print(load)
        res = make_response(json.dumps(load))
        res.mimetype = 'application/json'
        res.status_code = 200
        return res
    
    elif request.method == 'PATCH' or request.method == 'PUT':
        content = request.get_json()
        if "weight" not in content and "length" not in content and "creation_date" not in content:
            error_message = {
                "Error": "The request object is missing all of the attributes"
            }
            return (error_message, 400)

        if load == None:
            error_message = {
                "Error": "No load with this load_id exists"
            }
            res = make_response(json.dumps(error_message))
            res.mimetype = 'application/json'
            res.status_code = 404
            return res

        if 'weight' in content:
            load['weight'] = content['weight']
        if 'length' in content:
            load['length'] = content['length']
        if 'creation_date' in content:
            load['creation_date'] = content['creation_date']

        client.put(load)
        res = make_response(json.dumps(load))
        res.mimetype = 'application/json'
        res.status_code = 202
        return res

    elif request.method == 'DELETE':
        # update its carrier's loads property
        if load['carrier'] != None:
            carrier_id = int(load['carrier'])
            carrier_key = client.key(constants.boats, carrier_id)
            carrier = client.get(key=carrier_key)
            carrier_loads = carrier['loads']
            new_loads = []
            for load in carrier_loads:
                if load != load.key.id:
                    new_loads.append(load)
            if len(new_loads) == 0:
                carrier['loads'] = None
            else:
                carrier['loads'] = new_loads
            client.put(carrier)
        client.delete(load)
        client.put(load)
        res = make_response(json.dumps(''))
        res.mimetype = 'application/json'
        res.status_code = 204
        return res

    else:
        res = make_response(json.dumps('Method not recogonized'))
        res.mimetype = 'application/json'
        res.status_code = 405
        return res


# add/delete relationship between boat and loads
@app.route('/boats/<boat_id>/loads/<load_id>', methods=['POST', 'DELETE'])
def boat_load_add_delete_relation(boat_id, load_id):
    if 'Authorization' not in request.headers:
        # auth is missing
        return (jsonify(''),401)
    payload = verify_jwt(request) # check if jwt is valid
    boat_key = client.key(constants.boats, int(boat_id))
    boat = client.get(key=boat_key)
    load_key = client.key(constants.loads, int(load_id))
    load = client.get(key=load_key)

    if boat == None:
        error_message = {
            "Error": "The specified boat does not exist" 
        }
        return (error_message, 404)
    if boat['owner'] != None:
        user_key = client.key(constants.users, int(boat['owner']))
        user = client.get(key=user_key)
        if user == None:
            error_message = {
                "Error": "The specified user does not exist" 
            }
            return (error_message, 404)
        if user['user_id'] != payload['sub']:
            return (jsonify('Reject request'),403)

    if load == None or boat == None:
        error_message = {
            "Error": "The specified boat and/or load does not exist" 
        }
        res = make_response(json.dumps(error_message))
        res.mimetype = 'application/json'
        res.status_code = 404
        return res

    if request.method == 'POST':
        if load['carrier'] != None:
            error_message = {
                "Error":  "The load has already been assigned to a boat."
            }
            return (error_message, 400)
        load['carrier'] = boat_id
        if boat['loads'] == None:
            boat['loads'] = [load.key.id]
        else:
            boat['loads'].append(load.key.id)
        client.put(boat)
        client.put(load)
        res = make_response(json.dumps(''))
        res.mimetype = 'application/json'
        res.status_code = 204
        return res

    elif request.method == 'DELETE':
        if load['carrier'] != boat_id:
            error_message = {
                "Error":   'No such relation existed!'
            }
            res = make_response(json.dumps(error_message))
            res.mimetype = 'application/json'
            res.status_code = 404
        carrier_id = int(load['carrier'])
        carrier_key = client.key(constants.boats, carrier_id)
        carrier = client.get(key=carrier_key)
        carrier_loads = carrier['loads']
        new_loads = []
        for i in carrier_loads:
            if i != load.key.id:
                new_loads.append(load)
        if len(new_loads) == 0:
            carrier['loads'] = None
        else:
            carrier['loads'] = new_loads
        client.put(carrier)
        load.update({'carrier': None})
        client.put(load)
        res = make_response(json.dumps(''))
        res.mimetype = 'application/json'
        res.status_code = 204
        return res
    else:
        res = make_response(json.dumps('Method not recogonized'))
        res.mimetype = 'application/json'
        res.status_code = 405
        return res


# add relationship between user and boat
@app.route('/users/<user_id>/boats/<boat_id>', methods=['POST', 'DELETE'])
def user_boat_add_delete_relation(user_id,boat_id):
    if 'Authorization' not in request.headers:
        # auth is missing
        return (jsonify(''),401)
    payload = verify_jwt(request) # check if jwt is valid
    user_key = client.key(constants.users, int(user_id))
    user = client.get(key=user_key)
    if user == None:
        error_message = {
            "Error": "The specified user does not exist" 
        }
        return (error_message, 404)
    if user['user_id'] != payload['sub']:
        return (jsonify('Reject request'),403)

    boat_key = client.key(constants.loads, int(boat_id))
    user = client.get(key=user_key)
    boat = client.get(key=boat_key)
    if boat == None:
        error_message = {
            "Error": "The specified boat does not exist" 
        }
        return (error_message, 404)

    if request.method == 'POST':
        if boat['owner'] != None:
            error_message = {
                "Error": "The boat has already been owned by a user."
            }
            res = make_response(json.dumps(error_message))
            res.mimetype = 'application/json'
            res.status_code = 403
            return res
        boat['owner'] = user_id
        client.put(boat)
        res = make_response(json.dumps(''))
        res.mimetype = 'application/json'
        res.status_code = 204
        return res
    elif request.method == 'DELETE':
        if boat['owner'] != user_id:
            error_message = {
                "Error":   'No such relation existed!'
            }
            res = make_response(json.dumps(error_message))
            res.mimetype = 'application/json'
            res.status_code = 404
            return res
        res = make_response(json.dumps(''))
        res.mimetype = 'application/json'
        res.status_code = 204
        return res
    else:
        res = make_response(json.dumps('Method not recogonized'))
        res.mimetype = 'application/json'
        res.status_code = 405
        return res


@app.route('/callback')
def callback_handling():
    # Handles response from token endpoint
    session['jwt'] = auth0.authorize_access_token()["id_token"]
    resp = auth0.get('userinfo')
    userinfo = resp.json()

    # Store the user information in flask session.
    session['jwt_payload'] = userinfo
    session['profile'] = {
        'user_id': userinfo['sub'],
        'name': userinfo['name'],
        'picture': userinfo['picture']
    }
    return redirect('/dashboard')
    

@app.route('/dashboard')
#@requires_auth
def dashboard():
    query = client.query(kind=constants.users)
    all_users = list(query.fetch())
    for e in all_users:
        if e['user_id'] == session['profile']['user_id']:
            return render_template('dashboard.html', user_id=session['profile']['user_id'], jwt=session['jwt'])
    
    new_user = datastore.entity.Entity(key=client.key(constants.users))
    new_user['user_id'] = session['profile']['user_id']
    client.put(new_user)
    return render_template('dashboard.html', user_id=session['profile']['user_id'], jwt=session['jwt'])


def is_boat_unique(new_boat_name):
    query = client.query(kind=constants.boats)
    results = list(query.fetch())
    for e in results:
        if e["name"] == new_boat_name:
            return False
    return True


def check_accept_mimetypes(resquest):
    if 'application/json' not in request.accept_mimetypes:
        error_message = {
            "Error": "Requests a content type not supported by the endpoint."
        }
        res = make_response(json.dumps(error_message))
        res.mimetype = 'application/json'
        res.status_code = 406
        return res
    else:
        return None

if __name__ == '__main__':
    app.run(host='127.0.0.1', port=8080, debug=True)