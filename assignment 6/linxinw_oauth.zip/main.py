from flask import Flask, render_template, request, url_for, redirect, session
import random
import string
import requests

app = Flask(__name__, static_url_path='/static')
app.secret_key = "super secret key"
#host_url = "http://127.0.0.1:8080"
host_url = "https://assignment-6-312907.ue.r.appspot.com"

@app.route('/')
def index():
    return "Please navigate to /oauth to use this API"


@app.route('/oauth', methods=['GET'])
def oauth_get_post():
    if request.method == 'GET':
        if request.args.get("state") != None:
            # the page is redirected
            real_state = session['state']
            state = request.args.get("state")
            if state != real_state:
                return redirect(url_for('oauth_get_post'))
            code = request.args.get("code")

            # using 'code' to get access token from google
            link = "https://www.googleapis.com/oauth2/v4/token?code=" + code + "&client_id=328006827989-rsrqodvo0q5tuv2qj9hot7qlvrq41hnm.apps.googleusercontent.com&client_secret=jrNlun1wfVJgvwdVFrLdiala&redirect_uri=" + host_url + "/oauth&grant_type=authorization_code"
            res = requests.post(link)
            res = res.json()
            session["access_token"] = res["access_token"]
            session["token_type"] = res["token_type"]
            session["expires_in"] = res["expires_in"]
            session["id_token"] = res["id_token"]
            # using 'access_token' to get user data from google

            link = 'https://people.googleapis.com/v1/people/me?personFields=names'
            headers_dict = {"Authorization": "Bearer " + session['access_token']}
            res = requests.get(link, headers=headers_dict)
            res = res.json()
            session['firstname'] = res["names"][0]["givenName"]
            session['lastname'] = res["names"][0]["familyName"]
            return redirect(host_url + "/userinfo")
        else:
            # when the page is not being redirecting
            state = id_generator()
            link = "https://accounts.google.com/o/oauth2/v2/auth?response_type=code&client_id=328006827989-rsrqodvo0q5tuv2qj9hot7qlvrq41hnm.apps.googleusercontent.com&redirect_uri=" + host_url + "/oauth&scope=profile&state=" + state
            session["state"] = state
            return render_template('index.html', link = link)


@app.route('/userinfo', methods=['GET'])
def userinfo_get_post():
    if request.method == 'GET':
        StateValue = session["state"]
        return render_template('userinfo.html', FirstName = session["firstname"], LastName = session["lastname"], state = StateValue)


# https://stackoverflow.com/questions/2257441/random-string-generation-with-upper-case-letters-and-digits
def id_generator(size=15, chars=string.ascii_uppercase + string.digits):
    random_string = ''
    for i in range(size):
        random_string = random_string + random.choice(chars)
    return random_string


if __name__ == '__main__':
    app.run(host='127.0.0.1', port=8080, debug=True)