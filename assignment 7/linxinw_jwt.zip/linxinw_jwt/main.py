from google.cloud import datastore
from flask import Flask, request, jsonify, _request_ctx_stack
import requests

from functools import wraps
import json

from six.moves.urllib.request import urlopen
from flask_cors import cross_origin
from jose import jwt


import json
from os import environ as env
from werkzeug.exceptions import HTTPException

from dotenv import load_dotenv, find_dotenv
from flask import Flask
from flask import jsonify
from flask import redirect
from flask import render_template
from flask import session
from flask import url_for
from authlib.integrations.flask_client import OAuth
from six.moves.urllib.parse import urlencode


app = Flask(__name__)
app.secret_key = 'SECRET_KEY'

client = datastore.Client()

LODGINGS = "lodgings"

CLIENT_ID = 'JXQbZDWeC77N1wQXjUQeaqGSMfgkWz1o'
CLIENT_SECRET = 'SBIvRcpMag1JFPIobDrj-X871OjEIdMWrov9_b0cqNAQ6r5pgM7WqetrnR6oO3eO'
DOMAIN = 'cs493-assignment7-linxinw.us.auth0.com'
HOSTURL = 'http://127.0.0.1:8080'
CALLBACK_URL = 'http://localhost:8080/callback'

ALGORITHMS = ["RS256"]


oauth = OAuth(app)

auth0 = oauth.register(
    'auth0',
    client_id=CLIENT_ID,
    client_secret=CLIENT_SECRET,
    api_base_url="https://" + DOMAIN,
    access_token_url="https://" + DOMAIN + "/oauth/token",
    authorize_url="https://" + DOMAIN + "/authorize",
    client_kwargs={
        'scope': 'openid profile email',
    },
)


# This code is adapted from https://auth0.com/docs/quickstart/backend/python/01-authorization?_ga=2.46956069.349333901.1589042886-466012638.1589042885#create-the-jwt-validation-decorator

class AuthError(Exception):
    def __init__(self, error, status_code):
        self.error = error
        self.status_code = status_code


@app.errorhandler(AuthError)
def handle_auth_error(ex):
    response = jsonify(ex.error)
    response.status_code = ex.status_code
    return response
    

def verify_jwt_return_pub_boats(request):
    auth_header = request.headers['Authorization'].split()
    token = auth_header[1]
    jsonurl = urlopen("https://"+ DOMAIN +"/.well-known/jwks.json")
    jwks = json.loads(jsonurl.read())
    boats = return_public_boats()
    try:
        unverified_header = jwt.get_unverified_header(token)
    except jwt.JWTError:
        raise AuthError(boats, 200)
    if unverified_header["alg"] == "HS256":
        raise AuthError(boats, 200)
    rsa_key = {}
    for key in jwks["keys"]:
        if key["kid"] == unverified_header["kid"]:
            rsa_key = {
                "kty": key["kty"],
                "kid": key["kid"],
                "use": key["use"],
                "n": key["n"],
                "e": key["e"]
            }
    if rsa_key:
        try:
            payload = jwt.decode(
                token,
                rsa_key,
                algorithms=ALGORITHMS,
                audience=CLIENT_ID,
                issuer="https://"+ DOMAIN+"/"
            )
        except jwt.ExpiredSignatureError:
            raise AuthError(boats, 200)
        except jwt.JWTClaimsError:
            raise AuthError(boats, 200)
        except Exception:
            raise AuthError(boats, 200)

        return payload
    else:
        raise AuthError(boats, 200)

def verify_jwt(request):
    auth_header = request.headers['Authorization'].split()
    token = auth_header[1]
    
    jsonurl = urlopen("https://"+ DOMAIN +"/.well-known/jwks.json")
    jwks = json.loads(jsonurl.read())
    try:
        unverified_header = jwt.get_unverified_header(token)
    except jwt.JWTError:
        raise AuthError({"code": "invalid_header",
                        "description":
                            "Invalid header. "
                            "Use an RS256 signed JWT Access Token"}, 401)
    if unverified_header["alg"] == "HS256":
        raise AuthError({"code": "invalid_header",
                        "description":
                            "Invalid header. "
                            "Use an RS256 signed JWT Access Token"}, 401)
    rsa_key = {}
    for key in jwks["keys"]:
        if key["kid"] == unverified_header["kid"]:
            rsa_key = {
                "kty": key["kty"],
                "kid": key["kid"],
                "use": key["use"],
                "n": key["n"],
                "e": key["e"]
            }
    if rsa_key:
        try:
            payload = jwt.decode(
                token,
                rsa_key,
                algorithms=ALGORITHMS,
                audience=CLIENT_ID,
                issuer="https://"+ DOMAIN+"/"
            )
        except jwt.ExpiredSignatureError:
            raise AuthError({"code": "token_expired",
                            "description": "token is expired"}, 401)
        except jwt.JWTClaimsError:
            raise AuthError({"code": "invalid_claims",
                            "description":
                                "incorrect claims,"
                                " please check the audience and issuer"}, 401)
        except Exception:
            raise AuthError({"code": "invalid_header",
                            "description":
                                "Unable to parse authentication"
                                " token."}, 401)

        return payload
    else:
        raise AuthError({"code": "no_rsa_key",
                            "description":
                                "No RSA key in JWKS"}, 401)


@app.route('/')
def index():
    return "Welcome, please navigate to /boats to use this API"\

@app.route('/boats', methods=['POST', 'GET'])
def lodgings_post():
    if request.method == 'POST':
        if 'Authorization' not in request.headers:
            # auth is missing
            return (jsonify(''),401)
        payload = verify_jwt(request)
        content = request.get_json()
        new_boat = datastore.entity.Entity(key=client.key(LODGINGS))
        new_boat.update({"name": content["name"], "type": content["type"],
          "length": content["length"], "public": content["public"], 
          "owner": payload["sub"]})
        client.put(new_boat)
        new_boat["id"] = new_boat.key.id
        return (jsonify(new_boat), 201)

    elif request.method == 'GET':
        if 'Authorization' not in request.headers:
            # auth is missing, return all public boats and 200 code
            query = client.query(kind=LODGINGS)
            results = list(query.fetch())
            return_list = []
            for e in results:
                if e['public'] == True:
                    e["id"] = e.key.id
                    return_list.append(e)
            return (jsonify(return_list), 200)
        else:
            # auth is provided
            payload = verify_jwt_return_pub_boats(request)
            query = client.query(kind=LODGINGS)
            results = list(query.fetch())
            user_token = payload["sub"]
            return_list = []
            for e in results:
                if e["owner"] == user_token:
                    # this boat belongs to this user
                    e["id"] = e.key.id
                    return_list.append(e)
            return (jsonify(return_list), 200)
    else:
        return (jsonify(error='Method not recogonized'), 400)


def return_public_boats():
    query = client.query(kind=LODGINGS)
    results = list(query.fetch())
    return_list = []
    for e in results:
        if e['public'] == True:
            e["id"] = e.key.id
            return_list.append(e)
    return return_list


@app.route('/owners/<id>/boats', methods=['GET'])
def owners_get_boat(id):
    if request.method == 'GET':
        query = client.query(kind=LODGINGS)
        results = list(query.fetch())
        return_list = []
        for e in results:
            if e["owner"] == id:
                # it is boat for this owner
                if e["public"] == True:
                    e["id"] = e.key.id
                    return_list.append(e)
        return (jsonify(return_list), 200)
    else:
        return jsonify(error='Method not recogonized')
        

@app.route('/boats/<id>', methods=['DELETE'])
def delete_boat(id):
    if request.method == 'DELETE':
        if 'Authorization' not in request.headers:
            # auth is missing
            return (jsonify(''),401)
        payload = verify_jwt(request) # if auth is invalid, this wil return 401 code

        key = client.key(LODGINGS, int(id))
        boat = client.get(key=key)
        if boat == None:
            error_message = {
                "Error": "No boat with this boat_id exists" 
            }
            return (jsonify(error_message), 403)
        if boat['owner'] == payload["sub"]:
            # owner matches the user, user can delete this boat
            print(boat['owner'])
            print(payload["sub"])
            client.delete(key)
            return (jsonify('boat deleted'), 204)
        else:
            # owner does not match the user, user cannot delete this boat
            return (jsonify(''), 403)

@app.route('/login', methods=['POST'])
def login_user():
    content = request.get_json()
    username = content["username"]
    password = content["password"]
    body = {'grant_type':'password','username':username,
            'password':password,
            'client_id':CLIENT_ID,
            'client_secret':CLIENT_SECRET
           }
    headers = { 'content-type': 'application/json' }
    url = 'https://' + DOMAIN + '/oauth/token'
    r = requests.post(url, json=body, headers=headers)
    return r.text, 200, {'Content-Type':'application/json'}
            

@app.route('/callback')
def callback_handling():
    # Handles response from token endpoint
    auth0.authorize_access_token()
    resp = auth0.get('userinfo')
    userinfo = resp.json()

    # Store the user information in flask session.
    session['jwt_payload'] = userinfo
    session['profile'] = {
        'user_id': userinfo['sub'],
        'name': userinfo['name'],
        'picture': userinfo['picture']
    }
    return redirect('/dashboard')
        
@app.route('/ui_login')
def ui_login():
    return auth0.authorize_redirect(redirect_uri=CALLBACK_URL)
    
@app.route('/dashboard')
#@requires_auth
def dashboard():
    return render_template('dashboard.html',
                           userinfo=session['profile'],
                           userinfo_pretty=json.dumps(session['jwt_payload'], indent=4))    

if __name__ == '__main__':
    app.run(host='127.0.0.1', port=8080, debug=True)