from google.cloud import datastore
from flask import Flask, request
import json
import constants

app = Flask(__name__)
client = datastore.Client()

@app.route('/')
def index():
    return "Please navigate to /boats or /slips to use this API"\

@app.route('/boats', methods=['POST','GET'])
def boats_get_post():
    if request.method == 'POST':
        content = request.get_json()
        # error checking
        if "name" not in content or "type" not in content or "length" not in content:
            error_message = {
                "Error": "The request object is missing at least one of the required attributes"
            }
            return (error_message, 400)

        # error checking passed, create a new boat and return
        new_boat = datastore.entity.Entity(key=client.key(constants.boats))
        new_boat.update({"name": content["name"], "type": content["type"],
          "length": content["length"]})
        client.put(new_boat)
        new_boat["id"] =  str(new_boat.key.id)
        new_boat["self"] = request.url + '/' +  str(new_boat.key.id)
        return (new_boat, 201)
    elif request.method == 'GET':
        query = client.query(kind=constants.boats)
        print(query)
        results = list(query.fetch())
        for e in results:
            e["id"] = e.key.id
        return (json.dumps(results), 200)
    else:
        return ('Method not recognized', 400)

@app.route('/boats/<id>', methods=['PATCH','DELETE','GET'])
def boats_put_delete(id):
    if request.method == 'PATCH':
        content = request.get_json()
        # error checking
        if "name" not in content or "type" not in content or "length" not in content:
            error_message = {
                "Error": "The request object is missing at least one of the required attributes"
            }
            return (error_message, 400)

        boat_key = client.key(constants.boats, int(id))
        boat = client.get(key=boat_key)

        # if boat is empty, means no corresponding boat has the same ID
        if boat == None:
            error_message = {
                "Error": "No boat with this boat_id exists"
            }
            return (error_message, 404)
        boat.update({"name": content["name"], "type": content["type"],
          "length": content["length"]})
        client.put(boat)
        boat["id"] = boat.key.id
        boat["self"] = request.url
        
        return (boat,200)
    elif request.method == 'DELETE':
        # check if the boat exist, then delete the boat
        key = client.key(constants.boats, int(id))
        boat = client.get(key=key)
        if boat == None:
            error_message = {
                "Error": "No boat with this boat_id exists" 
            }
            return (error_message, 404)
        client.delete(key)

        # also delete slip that has current_boat assigned to that boat
        query = client.query(kind=constants.slips)
        results = list(query.fetch())
        for e in results:
            if e["current_boat"] == str(id):
                e["current_boat"] = None
                client.put(e)
        return ('',204)
    elif request.method == 'GET':
        boat_key = client.key(constants.boats, int(id))
        boat = client.get(key=boat_key)
        if boat == None:
            error_message = {
                "Error": "No boat with this boat_id exists"
            }
            return (error_message, 404)
        boat["id"] = boat.key.id
        boat["self"] = request.url
        return (json.dumps(boat), 200)
    else:
        return 'Method not recognized'


@app.route('/slips', methods=['POST','GET'])
def slips_get_post():
    if request.method == 'POST':
        content = request.get_json()
        # error checking
        if "number" not in content:
            error_message = {
                "Error":  "The request object is missing the required number" 
            }
            return (error_message, 400)

        # error checking passed, create a new slip and return
        new_slip = datastore.entity.Entity(key=client.key(constants.slips))
        new_slip.update({"number": content["number"]})
        new_slip["current_boat"] = None
        client.put(new_slip)
        new_slip["self"] = request.url + '/' +  str(new_slip.key.id)
        new_slip["id"] =  str(new_slip.key.id)
        return (new_slip, 201)
    elif request.method == 'GET':
        query = client.query(kind=constants.slips)
        results = list(query.fetch())
        for e in results:
            e["id"] = e.key.id
            e["self"] = request.url + '/' +  str(e.key.id)
        
        return (json.dumps(results), 200)
    else:
        return ('Method not recognized', 400)


@app.route('/slips/<id>', methods=['PATCH','DELETE','GET'])
def slips_put_delete(id):
    if request.method == 'PATCH':
        content = request.get_json()
        # error checking
        if "name" not in content or "type" not in content or "length" not in content:
            error_message = {
                "Error": "The request object is missing at least one of the required attributes"
            }
            return (error_message, 400)

        slip_key = client.key(constants.slips, int(id))
        slip = client.get(key=slip_key)

        # if boat is empty, means no corresponding boat has the same ID
        if slip == None:
            error_message = {
                "Error": "No boat with this boat_id exists"
            }
            return (error_message, 404)
        slip.update({"name": content["name"], "type": content["type"],
            "length": content["length"]})
        client.put(slip)
        slip["id"] = slip.key.id
        slip["self"] = request.url
        
        return (slip,200)
    elif request.method == 'DELETE':
        slip_key = client.key(constants.slips, int(id))
        slip = client.get(key=slip_key)
        if slip == None:
            error_message = {
                "Error": "No slip with this slip_id exists" 
            }
            return (error_message, 404)
        client.delete(slip_key)
        return ('',204)
    elif request.method == 'GET':
        slip_key = client.key(constants.slips, int(id))
        slip = client.get(key=slip_key)
        if slip == None:
            error_message = {
                "Error": "No slip with this slip_id exists"
            }
            return (error_message, 404)
        slip["id"] = slip.key.id
        slip["self"] = request.url
        return (json.dumps(slip), 200)
    else:
        return 'Method not recognized'


@app.route('/slips/<slipID>/<boatID>', methods=['PUT','DELETE','GET'])
def assign_boat_to_slip(slipID, boatID):
    if request.method == 'PUT':
        # get slip from client
        slip_key = client.key(constants.slips, int(slipID))
        slip = client.get(key=slip_key)
        # get boat from client
        boat_key = client.key(constants.boats, int(boatID))
        boat = client.get(key=boat_key)
        if slip == None or boat == None:
            error_message = {
                "Error": "The specified boat and/or slip does not exist" 
            }
            return (error_message, 404)
    
        if slip["current_boat"] != None:
            error_message = {
                "Error":  "The slip is not empty" 
            }
            return (error_message, 403)
        slip.update({"current_boat": str(boatID)})
        client.put(slip)
        return ('',204)

    elif request.method == 'DELETE':
        # get slip from client
        slip_key = client.key(constants.slips, int(slipID))
        slip = client.get(key=slip_key)
        # get boat from client
        boat_key = client.key(constants.boats, int(boatID))
        boat = client.get(key=boat_key)
        if slip == None or boat == None:
            error_message = {
                "Error":  "No boat with this boat_id is at the slip with this slip_id" 
            }
            return (error_message, 404)
    
        if slip["current_boat"] != str(boatID):
            error_message = {
                "Error":   "No boat with this boat_id is at the slip with this slip_id" 
            }
            return (error_message, 404)
        
        slip.update({"current_boat": None})
        client.put(slip)
        return ('',204)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8000, debug=True)