from google.cloud import datastore
from flask import Flask, request
import json
import constants

app = Flask(__name__)
client = datastore.Client()

@app.route('/')
def index():
    return "Please navigate to /boats or /loads to use this API"\

@app.route('/boats', methods=['POST','GET'])
def boats_get_post():
    if request.method == 'POST':
        content = request.get_json()
        # error checking
        if "name" not in content or "type" not in content or "length" not in content:
            error_message = {
                "Error": "The request object is missing at least one of the required attributes"
            }
            return (error_message, 400)

        # error checking passed, create a new boat and return
        new_boat = datastore.entity.Entity(key=client.key(constants.boats))
        new_boat.update({"name": content["name"], "type": content["type"],
          "length": content["length"]})
        client.put(new_boat)
        new_boat["id"] =  str(new_boat.key.id)
        new_boat["self"] = request.url + '/' +  str(new_boat.key.id)
        return (new_boat, 201)
    elif request.method == 'GET':
        query = client.query(kind=constants.boats)
        q_limit = int(request.args.get('limit', '3'))
        q_offset = int(request.args.get('offset', '0'))
        l_iterator = query.fetch(limit= q_limit, offset=q_offset)
        pages = l_iterator.pages
        results = list(next(pages))
        if l_iterator.next_page_token:
            next_offset = q_offset + q_limit
            next_url = request.base_url + "?limit=" + str(q_limit) + "&offset=" + str(next_offset)
        else:
            next_url = None
        for e in results:
            e["id"] = e.key.id
            e['self'] = request.url + '/' +  str(e.key.id)
        output = {"boats": results}
        if next_url:
            output["next"] = next_url
        return json.dumps(output)
    else:
        return ('Method not recognized', 400)

@app.route('/boats/<id>', methods=['PATCH','DELETE','GET'])
def boats_put_delete(id):
    if request.method == 'PATCH':
        content = request.get_json()
        # error checking
        if "name" not in content or "type" not in content or "length" not in content:
            error_message = {
                "Error": "The request object is missing at least one of the required attributes"
            }
            return (error_message, 400)

        boat_key = client.key(constants.boats, int(id))
        boat = client.get(key=boat_key)

        # if boat is empty, means no corresponding boat has the same ID
        if boat == None:
            error_message = {
                "Error": "No boat with this boat_id exists"
            }
            return (error_message, 404)
        boat.update({"name": content["name"], "type": content["type"],
          "length": content["length"]})
        client.put(boat)
        boat["id"] = boat.key.id
        boat["self"] = request.url
        return (boat,200)
    elif request.method == 'DELETE':
        # check if the boat exist, then delete the boat
        key = client.key(constants.boats, int(id))
        boat = client.get(key=key)
        if boat == None:
            error_message = {
                "Error": "No boat with this boat_id exists" 
            }
            return (error_message, 404)
        client.delete(key)

        # also delete loads that has current_boat assigned to that boat
        query = client.query(kind=constants.loads)
        results = list(query.fetch())
        for e in results:
            if e["carrier"] == int(id):
                e["carrier"] = None
                client.put(e)
        return ('',204)
    elif request.method == 'GET':
        boat_key = client.key(constants.boats, int(id))
        boat = client.get(key=boat_key)
        if boat == None:
            error_message = {
                "Error": "No boat with this boat_id exists"
            }
            return (error_message, 404)
        boat["id"] = boat.key.id
        boat["self"] = request.url

            
        if 'loads' in boat.keys():
            i = 0
            for item in boat['loads']:
                s = request.host_url + 'loads/' +  item
                new_item = {
                    'id': boat['loads'][i], 
                    'self': s
                }
                boat['loads'][i] = new_item
                i += 1
            if i==0:
                del boat['loads']

        return (json.dumps(boat), 200)
    else:
        return 'Method not recognized'


@app.route('/boats/<boatID>/loads', methods=['GET'])
def get_all_loads(boatID):
    boat_key = client.key(constants.boats, int(boatID))
    boat = client.get(key=boat_key)
    if boat == None:
        error_message = {
            "Error": "No boat with this boat_id exists"
        }
        return (error_message, 404)
    # if boat exists, return all its loads
    load_list = []
    id_list = []
    if 'loads' in boat.keys():
        for gid in boat['loads']:
            load_key = client.key(constants.loads, int(gid))
            load_list.append(load_key)
            message = json.dumps(client.get_multi(load_list))
        return message
    return json.dumps([])


@app.route('/loads', methods=['POST','GET'])
def loads_get_post():
    if request.method == 'POST':
        content = request.get_json()
        # error checking
        if "volume" not in content or "content" not in content or "creation_date" not in content:
            error_message = {
                "Error": "The request object is missing at least one of the required attributes"
            }
            return (error_message, 400)

        # error checking passed, create a new load and return
        new_load = datastore.entity.Entity(key=client.key(constants.loads))
        new_load.update({"volume": content["volume"], "content": content["content"], "creation_date": content["creation_date"]})
        new_load["carrier"] = None
        client.put(new_load)
        new_load["self"] = request.url + '/' +  str(new_load.key.id)
        new_load["id"] =  str(new_load.key.id)
        return (new_load, 201)
    elif request.method == 'GET':
        query = client.query(kind=constants.loads)
        q_limit = int(request.args.get('limit', '3'))
        q_offset = int(request.args.get('offset', '0'))
        l_iterator = query.fetch(limit= q_limit, offset=q_offset)
        pages = l_iterator.pages
        results = list(next(pages))
        if l_iterator.next_page_token:
            next_offset = q_offset + q_limit
            next_url = request.base_url + "?limit=" + str(q_limit) + "&offset=" + str(next_offset)
        else:
            next_url = None
        for e in results:
            e["id"] = e.key.id
            e["self"] = request.url + '/' +  str(e.key.id)
        output = {"loads": results}
        if next_url:
            output["next"] = next_url
        return json.dumps(output)
    else:
        return ('Method not recognized', 400)


@app.route('/loads/<id>', methods=['PATCH','DELETE','GET'])
def loads_put_delete(id):
    if request.method == 'PATCH':
        content = request.get_json()
        # error checking
        if "name" not in content or "type" not in content or "length" not in content:
            error_message = {
                "Error": "The request object is missing at least one of the required attributes"
            }
            return (error_message, 400)

        load_key = client.key(constants.slips, int(id))
        load = client.get(key=load_key)

        # if boat is empty, means no corresponding boat has the same ID
        if load == None:
            error_message = {
                "Error": "No boat with this boat_id exists"
            }
            return (error_message, 404)
        load.update({"name": content["name"], "type": content["type"],
            "length": content["length"]})
        client.put(load)
        load["id"] = load.key.id
        load["self"] = request.url
        
        return (load,200)
    elif request.method == 'DELETE':
        load_key = client.key(constants.loads, int(id))
        load = client.get(key=load_key)
        if load == None:
            error_message = {
                "Error": "No load with this load_id exists" 
            }
            return (error_message, 404)
        carrier_boat = load['carrier']
        client.delete(load_key)

        if carrier_boat == None:
            return ('',204)

        # get carrier boat
        key = client.key(constants.boats, int(carrier_boat))
        carrier_boat = client.get(key=key)

        # delete corresponding boat
        i = 0
        for item in carrier_boat['loads']:
            if item == id:
                # delete corresponding load from boat['loads']
                del carrier_boat['loads'][i]
                # check if boat['loads'] has nothing in it, if yes del boat[loads]
                if len(carrier_boat['loads']) == 0:
                    del carrier_boat['loads']
                # UPDATE
                client.put(carrier_boat)
            i += 1

        return ('',204)
    elif request.method == 'GET':
        load_key = client.key(constants.loads, int(id))
        load = client.get(key=load_key)
        if load == None:
            error_message = {
                "Error": "No load with this load_id exists"
            }
            return (error_message, 404)
        load["id"] = load.key.id
        load["self"] = request.url

        if 'carrier' in load.keys() and load['carrier'] != None:
            s = request.host_url + 'boats/' +  str(load['carrier'])
            new_item = {
                'id': int(load['carrier']), 
                'self': s
            }
            load['carrier'] = new_item
        return (json.dumps(load), 200)
    else:
        return 'Method not recognized'


@app.route('/boats/<boatID>/loads/<loadID>', methods=['PUT','DELETE','GET', 'PATCH'])
def assign_load_to_boat(boatID, loadID):
    if request.method == 'PUT':
        # get load from client
        load_key = client.key(constants.loads, int(loadID))
        load = client.get(key=load_key)
        # get boat from client
        boat_key = client.key(constants.boats, int(boatID))
        boat = client.get(key=boat_key)
        if load == None or boat == None:
            error_message = {
                "Error": "The specified boat and/or load does not exist" 
            }
            return (error_message, 404)
    
        if load["carrier"] != None:
            error_message = {
                "Error":  "The load has already been assigned to a boat" 
            }
            return (error_message, 403)

        load.update({"carrier": int(boatID)})

        if 'loads' in boat.keys():
            boat['loads'].append(loadID)
        else:
            boat['loads'] = [loadID]
        client.put(load)
        client.put(boat)
        return ('',204)

    elif request.method == 'DELETE':
        # get load from client
        load_key = client.key(constants.loads, int(loadID))
        load = client.get(key=load_key)
        # get boat from client
        boat_key = client.key(constants.boats, int(boatID))
        boat = client.get(key=boat_key)
        if load == None or boat == None:
            error_message = {
                "Error":  "Boat or/and load is not existed" 
            }
            return (error_message, 404)
    
        if 'loads' in boat.keys():
            i = 0
            for item in boat['loads']:
                if item == loadID:
                    # delete corresponding load from boat['loads']
                    del boat['loads'][i]
                    # check if boat['loads'] has nothing in it, if yes del boat[loads]
                    if len(boat['loads']) == 0:
                        del boat['loads']
                    # also delete carrier from load: set it to None
                    load['carrier'] = None
                    # UPDATE these two to client
                    client.put(load)
                    client.put(boat)
                    # return
                    return ('', 204)
                i += 1
        # however, loop ends which means no corresponding load found in boat[loads]
        # return error message and 404 status
        error_message = {
            "Error":   "Load is not on this boat" 
        }
        return (error_message, 403)
    
    elif request.method == 'PATCH':
        # get load
        load_key = client.key(constants.loads, int(loadID))
        load = client.get(key=load_key)

        # get old boat
        old_boatID = load['carrier']
        if old_boatID != None:
            old_boat_key = client.key(constants.boats, int(old_boatID))
            old_boat = client.get(key=old_boat_key)
            # delete load from old boat
            i = 0
            for item in old_boat['loads']:
                if item == loadID:
                    # delete corresponding load from boat['loads']
                    del old_boat['loads'][i]
                    # check if boat['loads'] has nothing in it, if yes del boat[loads]
                    if len(old_boat['loads']) == 0:
                        del old_boat['loads']
                    # also delete carrier from load: set it to None
                    load['carrier'] = None
                    # UPDATE these two to client
                    client.put(old_boat)
                i += 1
        
        # get new boat
        boat_key = client.key(constants.boats, int(boatID))
        boat = client.get(key=boat_key)

        # add the load to new boat
        load.update({"carrier": int(boatID)})
        if 'loads' in boat.keys():
            boat['loads'].append(loadID)
        else:
            boat['loads'] = [loadID]
        client.put(load)
        client.put(boat)

        # return
        return ('',200)

    else:
        return 'Method not recognized'



if __name__ == '__main__':
    app.run(host='127.0.0.1', port=8080, debug=True)