from google.cloud import datastore
from flask import Flask, request, make_response, redirect
import json
import constants
from json2html import *

app = Flask(__name__)
client = datastore.Client()

@app.route('/')
def index():
    return "Please navigate to /boats to use this API"\

@app.route('/boats', methods=['POST','GET'])
def boats_get_post():
    if request.method == 'POST':
        if request.content_type != 'application/json':
            error_message = {
                "Error": "Requests contains unsupported media type"
            }
            res = make_response(json.dumps(error_message))
            res.mimetype = 'application/json'
            res.status_code = 415
            return res
        content = request.get_json(force = True)
        if 'application/json' in request.accept_mimetypes:
            # error checking
            if "name" not in content or "type" not in content or "length" not in content:
                error_message = {
                    "Error": "The request object is missing at least one of the required attributes"
                }
                res = make_response(json.dumps(error_message))
                res.mimetype = 'application/json'
                res.status_code = 400
                return res

            # checking if new boat's name is unique, return false if it is not
            if not is_boat_unique(content["name"]):
                error_message = {
                    "Error": "The name of the boat is duplicated"
                }
                res = make_response(json.dumps(error_message))
                res.mimetype = 'application/json'
                res.status_code = 403
                return res

            # error checking passed, create a new boat and return
            new_boat = datastore.entity.Entity(key=client.key(constants.boats))
            new_boat.update({"name": content["name"], "type": content["type"],
            "length": content["length"]})
            client.put(new_boat)
            new_boat["id"] =  str(new_boat.key.id)
            new_boat["self"] = request.url + '/' +  str(new_boat.key.id)

            res = make_response(json.dumps(new_boat))
            res.mimetype = 'application/json'
            res.status_code = 200
            return res
        else:
            error_message = {
                    "Error": "Create a boat only supports application/json"
                }
            res = make_response(json.dumps(error_message))
            res.mimetype = 'application/json'
            res.status_code = 406
            return res

    elif request.method == 'GET':
        query = client.query(kind=constants.boats)
        q_limit = int(request.args.get('limit', '3'))
        q_offset = int(request.args.get('offset', '0'))
        l_iterator = query.fetch(limit= q_limit, offset=q_offset)
        pages = l_iterator.pages
        results = list(next(pages))
        if l_iterator.next_page_token:
            next_offset = q_offset + q_limit
            next_url = request.base_url + "?limit=" + str(q_limit) + "&offset=" + str(next_offset)
        else:
            next_url = None
        for e in results:
            e["id"] = e.key.id
            e['self'] = request.url + '/' +  str(e.key.id)
        output = {"boats": results}
        if next_url:
            output["next"] = next_url
        return json.dumps(output)
    else:
        error_message = {
            "Error": "Not supporting edit or delete of the entire list of boats!"
        }
        res = make_response(json.dumps(error_message))
        res.mimetype = 'application/json'
        res.status_code = 405
        return res

@app.route('/boats/<id>', methods=['PATCH','DELETE','GET','PUT'])
def boats_put_delete(id):
    if request.method == 'PATCH':
        if request.content_type != 'application/json':
            error_message = {
                "Error": "Requests contains unsupported media type"
            }
            res = make_response(json.dumps(error_message))
            res.mimetype = 'application/json'
            res.status_code = 415
            return res

        if 'application/json' in request.accept_mimetypes:
            content = request.get_json(force = True)
            # error checking
            if (("name" not in content) and ("type" not in content) and ('length' not in content)) or ("id" in content) or content == None:
                error_message = {
                    "Error": "The request object is missing at least one of the required attributes or trying to edit ID of a boat"
                }
                res = make_response(json.dumps(error_message))
                res.mimetype = 'application/json'
                res.status_code = 400
                return res
            
            if "name" in content:
                if not is_boat_unique(content["name"]):
                    error_message = {
                        "Error": "Replacing the name of the boat to an existing name of other boat is not allowed"
                    }
                    res = make_response(json.dumps(error_message))
                    res.mimetype = 'application/json'
                    res.status_code = 403
                    return res

            boat_key = client.key(constants.boats, int(id))
            boat = client.get(key=boat_key)

            # if boat is empty, means no corresponding boat has the same ID
            if boat == None:
                error_message = {
                    "Error": "No boat with this boat_id exists"
                }
                res = make_response(json.dumps(error_message))
                res.mimetype = 'application/json'
                res.status_code = 404
                return res
            
            if "name" in content:
                boat["name"] = content["name"]

            if "type" in content:
                boat["type"] = content["type"]

            if "length" in content:
                boat["length"] = content["length"]

            client.put(boat)
            boat["id"] = boat.key.id
            boat["self"] = request.url
            res = make_response(json.dumps(boat))
            res.mimetype = 'application/json'
            res.status_code = 200
            return res
        else:
            error_message = {
                    "Error": "Edit a boat only supports application/json"
                }
            res = make_response(json.dumps(error_message))
            res.mimetype = 'application/json'
            res.status_code = 406
            return res
    elif request.method == 'PUT':
        if request.content_type != 'application/json':
            error_message = {
                "Error": "Requests contains unsupported media type"
            }
            res = make_response(json.dumps(error_message))
            res.mimetype = 'application/json'
            res.status_code = 415
            return res
            
        # error checking
        content = request.get_json(force = True)
        if 'application/json' not in request.accept_mimetypes:
            error_message = {
                    "Error": "Edit a boat only supports application/json"
                }
            res = make_response(json.dumps(error_message))
            res.mimetype = 'application/json'
            res.status_code = 406
            return res
                
        if "name" not in content or "type" not in content or "length" not in content or "id" in content:
            error_message = {
                "Error": "The request object is missing at least one of the required attributes or trying to edit ID of a boat"
            }
            res = make_response(json.dumps(error_message))
            res.mimetype = 'application/json'
            res.status_code = 400
            return res

        boat_key = client.key(constants.boats, int(id))
        boat = client.get(key=boat_key)

        # if boat is empty, means no corresponding boat has the same ID
        if boat == None:
            error_message = {
                "Error": "No boat with this boat_id exists"
            }
            res = make_response(json.dumps(error_message))
            res.mimetype = 'application/json'
            res.status_code = 404
            return res

        # checking if new boat's name is unique, return false if it is not
        if not is_boat_unique(content["name"]):
            error_message = {
                "Error": "Replacing the name of the boat to an existing name of other boat is not allowed"
            }
            res = make_response(json.dumps(error_message))
            res.mimetype = 'application/json'
            res.status_code = 403
            return res
        
        boat.update({"name": content["name"], "type": content["type"],
            "length": content["length"]})
        client.put(boat)


        edited_boat_url = request.url
        res = make_response(json.dumps(None))
        res.mimetype = 'application/json'
        res.headers['Location'] = edited_boat_url
        res.status_code = 303
        return res
    elif request.method == 'DELETE':
        # check for content type first
        if 'application/json' in request.accept_mimetypes:
            # check if the boat exist, then delete the boat
            key = client.key(constants.boats, int(id))
            boat = client.get(key=key)
            if boat == None:
                error_message = {
                    "Error": "No boat with this boat_id exists" 
                }
                res = make_response(json.dumps(error_message))
                res.mimetype = 'application/json'
                res.status_code = 404
                return res

            client.delete(key)
            res = make_response(json.dumps(""))
            res.mimetype = 'application/json'
            res.status_code = 204
            return res
        else:
            error_message = {
                    "Error": "Delete a boat only supports application/json"
                }
            res = make_response(json.dumps(error_message))
            res.mimetype = 'application/json'
            res.status_code = 406
            return res
    elif request.method == 'GET':
        if 'application/json' not in request.accept_mimetypes and 'text/html' not in request.accept_mimetypes:
            error_message = {
                    "Error": "View a boat only supports application/json or text/html"
                }
            res = make_response(json.dumps(error_message))
            res.mimetype = 'application/json'
            res.status_code = 406
            return res
        
        if 'application/json' in request.accept_mimetypes:
            content_type = 'application/json'
        elif 'text/html' in request.accept_mimetypes:
            content_type = 'text/html'
        else:
            error_message = {
                    "Error": "View a boat only supports application/json or text/html"
                }
            res = make_response(json.dumps(error_message))
            res.mimetype = 'application/json'
            res.status_code = 406
            return res


        boat_key = client.key(constants.boats, int(id))
        boat = client.get(key=boat_key)
        if boat == None:
            error_message = {
                "Error": "No boat with this boat_id exists"
            }

            res = make_response(json.dumps(error_message))
            res.mimetype = content_type
            res.status_code = 404
            return res

        boat["id"] = boat.key.id
        boat["self"] = request.url
        if(content_type == 'application/json'):
            res = make_response(json.dumps(boat))
            res.mimetype = content_type
            res.status_code = 200
            return res
        else:
            res = make_response(json2html.convert(json = json.dumps(boat)))
            res.mimetype = content_type
            res.status_code = 200
            return res
    else:
        return 'Method not recognized'


def is_boat_unique(new_boat_name):
    query = client.query(kind=constants.boats)
    results = list(query.fetch())
    for e in results:
        if e["name"] == new_boat_name:
            return False
    return True



if __name__ == '__main__':
    app.run(host='127.0.0.1', port=8080, debug=True)